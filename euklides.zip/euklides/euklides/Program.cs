﻿using System;

class Program
{
    static int NWD(int a, int b)
    {
        if (b != 0)
        {
            return NWD(b, a % b);
        }
        return a;
    }

    static void Main(string[] args)
    {
        int a, b;
        Console.Write("Podaj dwie liczby: ");
        a = int.Parse(Console.ReadLine());
        b = int.Parse(Console.ReadLine());
        Console.WriteLine("NWD(" + a + "," + b + ") = " + NWD(a, b));
    }
}
